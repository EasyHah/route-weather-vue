# DistrictLayer 省份天气标注（含 24h 图表）
- 规划路线后，对经过的省份按指标着色
- 点省份 → ECharts 展示未来 24 小时 温度/风速/降水
使用：npm i && cp .env.example .env && 填写 Key 后 npm run dev